#include <string>
template <typename T>

class DSM{
private:
    T** matrix;
    int capacity;
    int elementCount;
    std::string* elementNames;

public:

    DSM(int elementCount);

    DSM(std::string* elementNames, int elementCount);

    DSM(const DSM& other);

    int size();

    std::string getName(int index);

    void setElementName(int index, const std::string& elementName);

    void addLink(const std::string &fromElement, const std::string& toElement, int weight);

    void deleteLink(const std::string& fromElement, const std::string& toElement);

    bool hasLink(const std::string& fromElement, const std::string& toElement);

    int linkWeight(const std::string& fromElement, const std::string& toElement);

    int countToLinks(const std::string& elementName);

    int countFromLinks(const std::string& elementName);

    int countAllLinks();

    void resize();

    void printMatrix();

    ~DSM();
};