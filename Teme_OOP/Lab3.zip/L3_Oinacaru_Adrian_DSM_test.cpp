#include "L3_Oinacaru_Adrian_DSM.h"
#include <cassert>
#include <iostream>

void UnitTests(){
    DSM<int> dsm(5);
    assert(dsm.size() == 0);

    // Testing constructor with element names
    std::string elements[5]={"A", "B", "C", "D", "E"};
    DSM<int> dsm2(elements, 5);
    assert(dsm2.size() == 5);

    // Testing getName method
    assert(dsm2.getName(0) == "A");
    assert(dsm2.getName(1) == "B");
    assert(dsm2.getName(2) == "C");
    assert(dsm2.getName(3) == "D");
    assert(dsm2.getName(4) == "E");

    // Testing setElementName method
    dsm2.setElementName(3, "d");
    assert(dsm2.getName(3) == "d");

    // Testing addLink method, for elementNames that are already in the array
    dsm2.addLink("B", "E", 5);
    dsm2.addLink("A", "E", 2);
    dsm2.addLink("C", "C", 6);
    assert(dsm2.linkWeight("B", "E") == 5);
    assert(dsm2.size() == 5);

    // Testing addLink method, for elementNames that are not already in the array
    dsm2.addLink("F", "G", 7);
    dsm2.addLink("G", "E", 2);
    //dsm2.printMatrix();

    // Testing deleteLink method
    dsm2.deleteLink("B", "E");
    dsm2.printMatrix();

    // Testing hasLink method
    assert(dsm2.hasLink("A", "E") == true);
    assert(dsm2.hasLink("B", "E") == false);

    // Testing linkWeight method
    assert(dsm2.linkWeight("C", "C") == 6);
    assert(dsm2.linkWeight("F", "G") == 7);
    assert(dsm2.linkWeight("A", "B") == 0);

    // Testing countToLinks method
    assert(dsm2.countToLinks("A") == 0);
    assert(dsm2.countToLinks("C") == 1);
    assert(dsm2.countToLinks("E") == 2);

    //Testing countFromLinks method
    assert(dsm2.countFromLinks("A") == 1);
    assert(dsm2.countFromLinks("C") == 1);
    assert(dsm2.countFromLinks("E") == 0);
    assert(dsm2.countFromLinks("G") == 1);

    //Testing countAllLinks method
    assert(dsm2.countAllLinks() == 4);
}

int main(){
    UnitTests();
    std::cout<<"TEST END"<<std::endl;
    return 0;
}