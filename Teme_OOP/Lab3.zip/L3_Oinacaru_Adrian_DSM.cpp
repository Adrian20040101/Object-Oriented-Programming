#include "L3_Oinacaru_Adrian_DSM.h"
#include <exception>
#include <iostream>
template class DSM<int>;
template class DSM<float>;
template class DSM<double>;

template <typename T>
DSM<T>::DSM(int elementCount) {
    this->elementCount = 0;
    this->capacity = elementCount;

    elementNames = new std::string[elementCount];

    matrix = new T* [elementCount];
    for (int row = 0; row < this->elementCount; row++)
        matrix[row] = new T[elementCount]{};    //initializes elements with 0
}

template <typename T>
DSM<T>::DSM(std::string* elementNames, int elementCount) {
    this->elementCount = elementCount;
    this->capacity = elementCount;

    this->elementNames = elementNames;

    matrix = new T* [elementCount];
    for (int row = 0; row < this->elementCount; row++)
        matrix[row] = new T[elementCount]{};
}

//Copy Constructor
template <typename T>
DSM<T>::DSM(const DSM& other) {
    this->capacity = other.capacity;
    this->elementCount = other.elementCount;
    this->elementNames = new std::string[capacity];
    for (int i = 0; i < this->elementCount; i++) {
        this->elementNames[i] = other.elementNames[i];
    }
    delete[] elementNames;
    elementNames = other.elementNames;
    this->matrix = new T* [capacity];
    for (int row = 0; row < this->capacity; row++) {
        this->matrix[row] = new T[capacity];
        for (int col = 0; col < this->capacity; col++) {
            this->matrix[row][col] = other.matrix[row][col];
        }
    }
}

template <typename T>
int DSM<T>::size() {
    return this->elementCount;
}

template <typename T>
std::string DSM<T>::getName(int index) {
    if (index < 0 || index > this->elementCount){
        throw std::exception();
    }
    else{
        return elementNames[index];
    }
}

template <typename T>
void DSM<T>::setElementName(int index, const std::string& elementName) {
    if (index < 0 || index > this->elementCount){
        throw std::exception();
    }
    else{
        elementNames[index] = elementName;
    }
}

template <typename T>
void DSM<T>::addLink(const std::string& fromElement, const std::string& toElement, int weight) {
    int fromIndex = -1;
    int toIndex = -1;

    // Find the indices of the fromElement and toElement
    for (int i = 0; i < this->elementCount; i++) {
        if (elementNames[i] == fromElement) {
            fromIndex = i;
        }
        if (elementNames[i] == toElement) {
            toIndex = i;
        }
    }

    if ((fromIndex == -1 || toIndex == -1) && this->capacity == this->elementCount)
        resize();

    // add the nonexistent element
    if (fromIndex == -1) {
        fromIndex = this->elementCount++;
        elementNames[fromIndex] = fromElement;
    }
    if (toIndex == -1) {
        toIndex = this->elementCount++;
        elementNames[toIndex] = toElement;
    }

    matrix[fromIndex][toIndex] = weight;
}

template <typename T>
void DSM<T>::deleteLink(const std::string& fromElement, const std::string& toElement) {
    int fromIndex = -1;
    int toIndex = -1;
    for (int i = 0; i < this->elementCount; i++) {
        if (elementNames[i] == fromElement) {
            fromIndex = i;
        }
        if (elementNames[i] == toElement) {
            toIndex = i;
        }
    }
    if (fromIndex != -1 && toIndex != -1){
        matrix[fromIndex][toIndex] = 0;   //setting weight to 0 (equivalent to removing a link)
    }
    else{
        throw std::exception();  //one or both elements are not included in the string array
    }
}

template <typename T>
bool DSM<T>::hasLink(const std::string& fromElement, const std::string& toElement) {
    int fromIndex = -1;
    int toIndex = -1;
    for (int i = 0; i < this->elementCount; i++) {
        if (elementNames[i] == fromElement) {
            fromIndex = i;
        }
        if (elementNames[i] == toElement) {
            toIndex = i;
        }
    }
    if (fromIndex != -1 && toIndex != -1 && matrix[fromIndex][toIndex] != 0){
        return true;
    }
    else{
        return false;
    }
}

template <typename T>
int DSM<T>::linkWeight(const std::string& fromElement, const std::string& toElement) {
    int fromIndex = -1;
    int toIndex = -1;
    for (int i = 0; i < this->elementCount; i++) {
        if (elementNames[i] == fromElement) {
            fromIndex = i;
        }
        if (elementNames[i] == toElement) {
            toIndex = i;
        }
    }
    if (fromIndex != -1 && toIndex != -1 && matrix[fromIndex][toIndex] != 0){
        return matrix[fromIndex][toIndex];
    }
    else{
        return 0;
    }
}

template <typename T>
int DSM<T>::countToLinks(const std::string& elementName) {
    int toIndex = -1;
    int count = 0;
    for (int i = 0; i < this->elementCount; i++){
        if (elementNames[i] == elementName)
            toIndex = i;
    }
    if (toIndex != -1){
        for (int i = 0; i < this->elementCount; i++) {
            if (matrix[i][toIndex] != 0) {
                count++;
            }
        }
    }
    else{
        throw std::exception();
    }
    return count;
}

template <typename T>
int DSM<T>::countFromLinks(const std::string& elementName) {
    int FromIndex = -1;
    int count = 0;
    for (int i = 0; i < this->elementCount; i++){
        if (elementNames[i] == elementName)
            FromIndex = i;
    }
    if (FromIndex != -1){
        for (int j = 0; j < this->elementCount; j++) {
            if (matrix[FromIndex][j] != 0) {
                count++;
            }
        }
    }
    else{
        throw std::exception();
    }
    return count;
}

template <typename T>
int DSM<T>::countAllLinks() {
    int count = 0;
    for (int i = 0; i < this->elementCount; i++){
        for (int j = 0; j < this->elementCount; j++){
            if (matrix[i][j] != 0){
                count++;
            }
        }
    }
    return count;
}

template <typename T>
void DSM<T>::resize() {
    this->capacity = (this->capacity + 1) * 2;
    auto* newElementNames = new std::string[capacity];
    //copying elements into new array
    for (int i = 0; i < this->elementCount; i++){
        newElementNames[i] = elementNames[i];
    }
    T** newMatrix = new T* [capacity];
    for (int row = 0; row < this->capacity; row++){
        newMatrix[row] = new T[capacity];
    }

    //copying links into new matrix, but also initializing new fields with 0
    for (int i = 0; i < this->capacity; i++){
        for (int j = 0; j < this->capacity; j++){
            if (i < this->elementCount && j < this->elementCount){
                newMatrix[i][j] = matrix[i][j];
            }
            else{
                newMatrix[i][j] = 0;
            }
        }
    }
    elementNames = newElementNames;
    for (int i = 0; i < this->elementCount; i++){
        delete[] matrix[i];
    }
    delete[] matrix;
    matrix = newMatrix;
}

template <typename T>
void DSM<T>::printMatrix() {
    std::cout<<"Elements: ";
    for (int i = 0; i < this->elementCount; i++){
        std::cout<<elementNames[i]<<" ";
    }
    std::cout<<std::endl<<std::endl;
    std::cout<<"Dependency Structured Matrix: "<<std::endl;
    std::cout << "     ";
    for (int i = 0; i < this->elementCount; i++) {
        std::cout << elementNames[i] << " ";
    }
    std::cout<<std::endl<<std::endl;
    for (int i = 0; i < this->elementCount; i++){
        std::cout<<elementNames[i]<<"    ";
        for (int j = 0 ; j < this->elementCount; j++){
            std::cout<<matrix[i][j]<<" ";
        }
        std::cout<<std::endl;
    }
    std::cout<<std::endl;
}

template <typename T>
DSM<T>::~DSM(){
    for (int row = 0; row < this->elementCount; row++){
        delete[] matrix[row];
    }
    delete[] matrix;
    delete[] elementNames;
}