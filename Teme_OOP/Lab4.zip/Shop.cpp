#pragma once
#include "tests.h"
#include "UI.h"
#include "controller.h"
#include "repository.h"
#include <iostream>

int main() {
    Test test;
    test.test_domain();
    test.test_repository();
    test.test_controller();
    std::cout << "All Tests Passed...\n";
    // We also have to include the namespaces where the constructors have been declared
    Repository::FruitRepo repo;
    Controller::FruitController ctrl (repo);
    UI::FruitUI ui(ctrl);
    ui.display_menu();
    ui.get_input();

}