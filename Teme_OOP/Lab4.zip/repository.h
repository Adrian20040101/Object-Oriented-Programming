#pragma once
#include "domain.h"
#include <memory>
#include <vector>
using namespace Domain;

namespace Repository{
    class FruitRepo {
    private:
        std::vector<Fruit> fruit_list;
    public:
        void add(const Fruit& new_fruit);

        bool remove(const std::string& name, const std::string& origin);

        std::vector<Fruit> get_all();
    };
}
