#include "controller.h"
#include <algorithm>

namespace Controller {

    ///the method takes attributes that need to be read from the user as parameters and calls the add method from the repository to add the fruit to the vector
    void FruitController::add(const std::string& name, const std::string& origin, const Domain::Fruit::Date& expiration_date, int quantity, int price) {
        Fruit fruit(name, origin, expiration_date, quantity, price);
        repo.add(fruit);
    }

    ///this method calls the remove method from the repository
    bool FruitController::remove(const std::string& name, const std::string& origin) {
        return repo.remove(name, origin);
    }

    ///this method iterates through the fruit vector and searches for matching name/origin between a fruit and a user input. It returns all the fruits that matched the search
    std::vector<Fruit> FruitController::find(const std::string& substring) {
        std::vector<Fruit> result;
        for (const auto& fruit : repo.get_all()) {
            if (fruit.get_name().find(substring) != -1 || fruit.get_origin().find(substring) != -1) {
                result.push_back(fruit);
            }
        }
        return result;
    }

    ///this method iterates through the fruit vector and returns all fruits that are low on supply (have a quantity less than that from the user input)
    std::vector<Fruit> FruitController::low_quantity(int searched_quantity) {
        std::vector<Fruit> result;
        for (const auto& fruit : repo.get_all()) {
            if (fruit.get_quantity() < searched_quantity) {
                result.push_back(fruit);
            }
        }
        return result;
    }

    ///this method sorts the fruits by their expiry date and returns the fruits in the new order
    std::vector<Fruit> FruitController::sort_expiration_date() {
        std::vector<Fruit> fruits = repo.get_all();
        //sorts the vector using a lambda expression and compares first the year, then the month and then the day
        std::sort(fruits.begin(), fruits.end(), [](const Fruit& fruit1, const Fruit& fruit2) {
            if (fruit1.get_expiration_date().year != fruit2.get_expiration_date().year) {
                return fruit1.get_expiration_date().year < fruit2.get_expiration_date().year;
            }
            else if (fruit1.get_expiration_date().month != fruit2.get_expiration_date().month) {
                return fruit1.get_expiration_date().month < fruit2.get_expiration_date().month;
            }
            else {
                return fruit1.get_expiration_date().day < fruit2.get_expiration_date().day;
            }
        });
        return fruits;
    }

    ///this method prints all the fruits in the order in they were added in the vector
    std::vector<Fruit> FruitController::print_all() {
        return repo.get_all();
    }

}