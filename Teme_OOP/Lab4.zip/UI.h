#pragma once
#include "controller.h"
using namespace Controller;

namespace UI{
    class FruitUI{
    private:
        FruitController& ctrl;
    public:
        FruitUI(FruitController& ctrl) : ctrl(ctrl) {}  // Initializes the ctrl, doesn't require further implementation

        void display_menu();

        void get_input();
    };
}

