#pragma once
#include "repository.h"
#include <vector>
using namespace Repository;

namespace Controller{
    class FruitController{
    private:
        FruitRepo& repo;
    public:
        FruitController(FruitRepo& repo) : repo(repo) {}  // Initializes the repo, doesn't need further implementation

        void add(const std::string& name, const std::string& origin, const Domain::Fruit::Date& expiration_date, int quantity, int price);

        bool remove(const std::string& name, const std::string& origin);

        std::vector<Fruit> find(const std::string& substring);

        std::vector<Fruit> low_quantity(int searched_quantity);

        std::vector<Fruit> sort_expiration_date();

        std::vector<Fruit> print_all();
    };
}
