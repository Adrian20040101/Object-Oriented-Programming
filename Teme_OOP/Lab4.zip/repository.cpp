#include "repository.h"
#include <vector>
#include <memory>
using namespace Repository;

///the add method adds a new fruit in the vector or updates the attributes of an already existing fruit
void FruitRepo::add(const Fruit& new_fruit){
    bool fruit_found = false;
    for (Fruit& fruit : fruit_list){
        // The method checks here if it needs to add a new fruit to the vector, or if it only has to update the quantity and price of a certain fruit that already exists
        // If so, then the new expiration date will be set to the lowest between the two fruits whose name and origin matched
        if (new_fruit.get_name() == fruit.get_name() && new_fruit.get_origin() == fruit.get_origin()){
            fruit.set_quantity(new_fruit.get_quantity() + fruit.get_quantity());
            fruit.set_price(new_fruit.get_price() + fruit.get_price());
            if (fruit.get_expiration_date().year > new_fruit.get_expiration_date().year)
                fruit.set_expiration_date(new_fruit.get_expiration_date().year, new_fruit.get_expiration_date().month, new_fruit.get_expiration_date().day);
            else if(fruit.get_expiration_date().year == new_fruit.get_expiration_date().year && fruit.get_expiration_date().month > new_fruit.get_expiration_date().month)
                fruit.set_expiration_date(new_fruit.get_expiration_date().year, new_fruit.get_expiration_date().month, new_fruit.get_expiration_date().day);
            else if(fruit.get_expiration_date().month == new_fruit.get_expiration_date().month && fruit.get_expiration_date().day > new_fruit.get_expiration_date().day)
                fruit.set_expiration_date(new_fruit.get_expiration_date().year, new_fruit.get_expiration_date().month, new_fruit.get_expiration_date().day);

            fruit_found = true;
            break;
        }
    }
    if (!fruit_found){
        fruit_list.push_back(new_fruit);
    }
}

///the method iterates through the vector and searches the name of the fruit to be removed. It is bool to easily check if a fruit has been removed or not
bool FruitRepo::remove (const std::string& name, const std::string& origin){
    for (auto itr = fruit_list.begin(); itr < fruit_list.end(); itr++){
        if (itr->get_name() == name && itr->get_origin() == origin){
            fruit_list.erase(itr);
            return true;
        }
    }
    return false;
}

///returns the vector containing all the fruits
std::vector<Fruit> FruitRepo::get_all() {
    return fruit_list;
}