#pragma once
#include <string>
#include <memory>

namespace Domain{
    class Fruit{
    private:
        std::string name;
        std::string origin;
        int quantity;
        int price;
    public:
        struct Date{
            int year;
            int month;
            int day;
        }expiration_date{};

        Fruit(const std::string& name, const std::string& origin, const Date& expiration_date, int quantity, int price);

        std::string get_name() const;

        std::string get_origin() const;

        Date get_expiration_date() const;

        int get_quantity() const;

        int get_price() const;

        void set_name(const std::string& other_name);

        void set_origin(const std::string& other_origin);

        void set_expiration_date(int year, int month, int day);

        void set_quantity(int other_quantity);

        void set_price(int other_price);


    };
}

