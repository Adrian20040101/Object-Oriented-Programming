#pragma once
class Test{
public:
    void test_domain();

    void test_repository();

    void test_controller();
};
