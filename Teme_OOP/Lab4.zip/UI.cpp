#include "UI.h"
#include <iostream>
#include <exception>
#include <string>
using namespace UI;

void FruitUI::display_menu() {
    std::cout << "****** MENU ******\n";
    std::cout << "1. Add a fruit\n";
    std::cout << "2. Remove a fruit\n";
    std::cout << "3. Search for fruit(s)\n";
    std::cout << "4. Search for low quantity fruits\n";
    std::cout << "5. Sort fruits by their expiration date\n";
    std::cout << "6. Print all fruits\n";
    std::cout << "7. Exit\n";
}

void FruitUI::get_input() {
    std::string input_str;
    int input;

    //we take the input as string and then convert it to integer, to be able to catch exceptions if the given input is not an integer
    do {
        std::cout << "Choose what you would like to do:";
        std::getline(std::cin, input_str);

        try {
            input = std::stoi(input_str);
        } catch (const std::invalid_argument& e) {
            std::cout << "Invalid input. Please enter an integer between 1 and 7.\n";
            continue;
        }

        if (input < 1 || input > 7) {
            std::cout << "Input must be an integer between 1 and 7.\n";
            continue;
        }

        switch (input) {
            ///taking user input for the add method and adding the fruit to the fruit vector
            case 1: {
                std::cout << std::endl;
                std::cout << "-------  Adding a fruit to the repository  -------\n";
                std::string name, origin, user_input;
                int year, month, day, quantity, price;
                std::cout << "Type the name of the fruit:";
                std::getline(std::cin, name);
                std::cout << "Type the origin of the fruit:";
                std::getline(std::cin, origin);
                std::cout << "Type the expiry date of the fruit:\n";
                std::cout << "Year:";
                std::getline(std::cin, user_input);
                year = stoi(user_input);
                std::cout << "Month:";
                std::getline(std::cin, user_input);
                month = std::stoi(user_input);
                std::cout << "Day:";
                std::getline(std::cin, user_input);
                day = std::stoi(user_input);
                std::cout << "Type the quantity of the fruits:";
                std::getline(std::cin, user_input);
                quantity = std::stoi(user_input);
                std::cout << "Type the price of the fruit:";
                std::getline(std::cin, user_input);
                price = std::stoi(user_input);

                ctrl.add(name, origin, {year, month, day}, quantity, price);

                std::cout << std::endl;
                std::cout << "The fruit has been added to the repository!" << std::endl;
                std::cout << std::endl;

                display_menu();
                break;
            }
            ///taking user input for the remove method (the name of the fruit)
            case 2: {
                std::cout << std::endl;
                std::cout << "-------  Removing a fruit to the repository  -------\n";
                std::string name, origin;
                std::cout << "Type the name of the fruit to be removed:";
                std::getline(std::cin, name);
                std::cout << "Type the origin of the fruit to be removed:";
                std::getline(std::cin, origin);
                if (ctrl.remove(name, origin)) {
                    std::cout << std::endl;
                    std::cout << "The fruit category has been removed!\n";
                    std::cout << std::endl;
                } else {
                    std::cout << std::endl;
                    std::cout << "No fruit matched your input!\n";
                    std::cout << std::endl;
                }
                display_menu();
                break;
            }
            ///taking user input for the substring to be searched in the fruits
            case 3: {
                std::cout << std::endl;
                std::cout << "-------  Searching for a fruit/fruits in the repository  -------\n";
                std::string substring;
                std::cout << "Type the part of the name or the origin of the fruit(s) you want to find:";
                std::getline(std::cin, substring);
                std::vector<Fruit> result = ctrl.find(substring);

                if (result.empty()) {
                    std::cout << std::endl;
                    std::cout << "No fruits found in the repository matching the search criteria.\n";
                    std::cout << std::endl;
                } else {
                    std::cout << std::endl;
                    std::cout << "All fruits in the repository that matched the search:" << std::endl;
                    for (const Fruit& f : result) {
                        std::cout << " ------------------------------------------------------" << std::endl;
                        std::cout << "Name: " << f.get_name() << std::endl
                                  << "Origin: " << f.get_origin() << std::endl
                                  << "Expiration Date: " << f.get_expiration_date().day << "/"
                                  << f.get_expiration_date().month << "/" << f.get_expiration_date().year << std::endl
                                  << "Quantity: " << f.get_quantity() << " kg" << std::endl
                                  << "Price: " << f.get_price() << "$" << std::endl;
                    }
                    std::cout << " ------------------------------------------------------" << std::endl;
                }

                display_menu();
                break;
            }
            ///taking user input in form of a string and then converting the string to an integer
            case 4:{
                std::cout << std::endl;
                std::cout << "-------  Searching for low quantity fruits in the repository  -------\n";
                std::string user_input;
                std::cout << "Type the quantity:";
                std::getline(std::cin, user_input);
                int searched_quantity = std::stoi(user_input);
                std::vector<Fruit> result = ctrl.low_quantity(searched_quantity);

                if (result.empty()) {
                    std::cout << std::endl;
                    std::cout << "No fruits found in the repository matching the search criteria.\n";
                    std::cout << std::endl;
                } else {
                    std::cout << std::endl;
                    std::cout << "All fruits in the repository that matched the search:" << std::endl;
                    for (const Fruit& f : result) {
                        std::cout << " ------------------------------------------------------" << std::endl;
                        std::cout << "Name: " << f.get_name() << std::endl
                                  << "Origin: " << f.get_origin() << std::endl
                                  << "Expiration Date: " << f.get_expiration_date().day << "/"
                                  << f.get_expiration_date().month << "/" << f.get_expiration_date().year << std::endl
                                  << "Quantity: " << f.get_quantity() << " kg" << std::endl
                                  << "Price: " << f.get_price() << "$" << std::endl;
                    }
                    std::cout << " ------------------------------------------------------" << std::endl;
                }
                display_menu();
                break;
            }
            ///sorting the fruits in the vector by their expiry date
            case 5: {
                std::cout << std::endl;
                std::cout << "-------  Sort fruits in the repository by their expiry date  -------\n";
                std::vector<Fruit> result = ctrl.sort_expiration_date();

                if (result.empty()) {
                    std::cout << std::endl;
                    std::cout << "No fruits found in the repository matching the search criteria.\n";
                    std::cout << std::endl;
                } else {
                    std::cout << std::endl;
                    std::cout << "All fruits in the repository that matched the search:" << std::endl;
                    for (const Fruit& f : result) {
                        std::cout << " ------------------------------------------------------" << std::endl;
                        std::cout << "Name: " << f.get_name() << std::endl
                                  << "Origin: " << f.get_origin() << std::endl
                                  << "Expiration Date: " << f.get_expiration_date().day << "/"
                                  << f.get_expiration_date().month << "/" << f.get_expiration_date().year << std::endl
                                  << "Quantity: " << f.get_quantity() << " kg" << std::endl
                                  << "Price: " << f.get_price() << "$" << std::endl;
                    }
                    std::cout << " ------------------------------------------------------" << std::endl;
                }
                display_menu();
                break;
            }
            ///print out all the fruits in the vector
            case 6: {
                std::cout << std::endl;
                std::cout << "-------  See all the fruits in the repository  -------\n";
                std::vector<Fruit> result = ctrl.print_all();

                if (result.empty()) {
                    std::cout << std::endl;
                    std::cout << "No fruits found in the repository matching the search criteria.\n";
                    std::cout << std::endl;
                } else {
                    std::cout << std::endl;
                    std::cout << "All fruits in the repository that matched the search:" << std::endl;
                    for (const Fruit& f : result) {
                        std::cout << " ------------------------------------------------------" << std::endl;
                        std::cout << "Name: " << f.get_name() << std::endl
                                  << "Origin: " << f.get_origin() << std::endl
                                  << "Expiration Date: " << f.get_expiration_date().day << "/"
                                  << f.get_expiration_date().month << "/" << f.get_expiration_date().year << std::endl
                                  << "Quantity: " << f.get_quantity() << " kg" << std::endl
                                  << "Price: " << f.get_price() << "$" << std::endl;
                    }
                    std::cout << " ------------------------------------------------------" << std::endl;
                }
                display_menu();
                break;
            }
            ///closing case where the program ends
            case 7:
                std::cout << "Thank you for using the application!\n";
                break;
            default:
                break;
        }
    //repeat the process until the Exit case is being called
    } while(input!=7);
}