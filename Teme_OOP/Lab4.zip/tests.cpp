#include "tests.h"
#include "domain.h"
#include "repository.h"
#include "controller.h"
#include "UI.h"
#include <cassert>
#include <iostream>

void Test::test_domain(){
    Fruit fruit1("Banana", "Africa", {2023, 6, 12}, 100, 134);
    Fruit fruit2("Kiwi", "Cuba", {2023, 5, 24}, 67, 100);

    // Testing attributes for the first fruit
    assert(fruit1.get_name() == "Banana");
    assert(fruit1.get_origin() == "Africa");
    assert(fruit1.get_expiration_date().year == 2023);
    assert(fruit1.get_expiration_date().month == 6);
    assert(fruit1.get_expiration_date().day == 12);
    assert(fruit1.get_quantity() == 100);
    assert(fruit1.get_price() == 134);

    // Testing modifying attributes
    fruit1.set_name("banana");
    fruit1.set_origin("africa");
    fruit1.set_expiration_date(2024, 1, 24);
    fruit1.set_quantity(200);
    fruit1.set_price(256);

    // Testing attributes after they have been modified
    assert(fruit1.get_name() == "banana");
    assert(fruit1.get_origin() == "africa");
    assert(fruit1.get_expiration_date().year == 2024);
    assert(fruit1.get_expiration_date().month == 1);
    assert(fruit1.get_expiration_date().day == 24);
    assert(fruit1.get_quantity() == 200);
    assert(fruit1.get_price() == 256);

    // Testing attributes for the second fruit
    assert(fruit2.get_name() == "Kiwi");
    assert(fruit2.get_origin() == "Cuba");
    assert(fruit2.get_expiration_date().year == 2023);
    assert(fruit2.get_expiration_date().month == 5);
    assert(fruit2.get_expiration_date().day == 24);
    assert(fruit2.get_quantity() == 67);
    assert(fruit2.get_price() == 100);

    // Testing modifying attributes
    fruit2.set_name("apple");
    fruit2.set_origin("romania");
    fruit2.set_expiration_date(2024, 5, 12);
    fruit2.set_quantity(100);
    fruit2.set_price(134);

    // Testing attributes after they have been modified
    assert(fruit2.get_name() == "apple");
    assert(fruit2.get_origin() == "romania");
    assert(fruit2.get_expiration_date().year == 2024);
    assert(fruit2.get_expiration_date().month == 5);
    assert(fruit2.get_expiration_date().day == 12);
    assert(fruit2.get_quantity() == 100);
    assert(fruit2.get_price() == 134);

    std::cout << "Domain Tests Passed...\n";
}

void Test::test_repository() {
    FruitRepo repository;
    Fruit fruit1("Banana", "Africa", {2023, 6, 12}, 100, 134);
    Fruit fruit2("Kiwi", "Cuba", {2023, 5, 24}, 67, 100);
    Fruit fruit3("Orange", "Spain", {2023, 6, 5}, 75, 150);

    // Testing the add method
    repository.add(fruit1);
    repository.add(fruit2);
    repository.add(fruit3);

    // Testing the get_all method
    // Comparing only the name attribute, the other attributes have been verified in the domain test
    std::vector<Fruit> expected_result = repository.get_all();
    assert(expected_result.size() == 3);
    assert(expected_result[0].get_name() == fruit1.get_name());
    assert(expected_result[1].get_name() == fruit2.get_name());
    assert(expected_result[2].get_name() == fruit3.get_name());

    // Testing the remove method
    assert(repository.remove("Kiwi", "Cuba") == true);
    assert(repository.remove("Watermelon", "Antarctica") == false);
    expected_result = repository.get_all();
    assert(expected_result.size() == 2);
    assert(expected_result[0].get_name() == fruit1.get_name());
    assert(expected_result[1].get_name() == fruit3.get_name());

    std::cout << "Repository Tests Passed...\n";
}

void Test::test_controller() {
    FruitRepo repository;
    FruitController ctrl(repository);
    Fruit fruit1("Banana", "Africa", {2023, 6, 12}, 100, 134);
    Fruit fruit2("Kiwi", "Cuba", {2023, 5, 24}, 67, 100);
    Fruit fruit3("Orange", "Spain", {2023, 6, 5}, 75, 150);

    // Testing add method via the controller
    ctrl.add(fruit1.get_name(), fruit1.get_origin(), fruit1.get_expiration_date(), fruit1.get_quantity(), fruit1.get_price());
    ctrl.add(fruit2.get_name(), fruit2.get_origin(), fruit2.get_expiration_date(), fruit2.get_quantity(), fruit2.get_price());
    ctrl.add(fruit3.get_name(), fruit3.get_origin(), fruit3.get_expiration_date(), fruit3.get_quantity(), fruit3.get_price());

    std::vector<Fruit> expected_result = repository.get_all();
    assert(expected_result.size() == 3);
    assert(expected_result[0].get_name() == fruit1.get_name());
    assert(expected_result[1].get_name() == fruit2.get_name());
    assert(expected_result[2].get_name() == fruit3.get_name());

    // Testing the remove method via controller
    ctrl.remove(fruit3.get_name(), fruit3.get_origin());
    expected_result = repository.get_all();
    assert(expected_result.size() == 2);
    assert(expected_result[0].get_name() == fruit1.get_name());
    assert(expected_result[1].get_name() == fruit2.get_name());

    // Testing find when it finds a match
    expected_result = ctrl.find("Kiw");
    assert(expected_result[0].get_name() == fruit2.get_name());

    // Testing find in the case where it hasn't found anything
    expected_result = ctrl.find("Watermel");
    assert(expected_result.empty() == true);

    //Testing low quantity method
    expected_result = ctrl.low_quantity(150);
    assert(expected_result[0].get_name() == fruit1.get_name());
    assert(expected_result[1].get_name() == fruit2.get_name());

    // Testing low quantity method when there is only one match
    expected_result = ctrl.low_quantity(75);
    assert(expected_result[0].get_name() == fruit2.get_name());

    // Testing sort expiration date method
    expected_result = ctrl.sort_expiration_date();
    assert(expected_result[0].get_name() == fruit2.get_name());
    assert(expected_result[1].get_name() == fruit1.get_name());

    // Testing print all method
    expected_result = ctrl.print_all();
    assert(expected_result[0].get_name() == "Banana");
    assert(expected_result[0].get_origin() == "Africa");
    assert(expected_result[0].get_expiration_date().year == 2023);
    assert(expected_result[0].get_expiration_date().month == 6);
    assert(expected_result[0].get_expiration_date().day == 12);
    assert(expected_result[0].get_quantity() == 100);
    assert(expected_result[0].get_price() == 134);
    assert(expected_result[1].get_name() == "Kiwi");
    assert(expected_result[1].get_origin() == "Cuba");
    assert(expected_result[1].get_expiration_date().year == 2023);
    assert(expected_result[1].get_expiration_date().month == 5);
    assert(expected_result[1].get_expiration_date().day == 24);
    assert(expected_result[1].get_quantity() == 67);
    assert(expected_result[1].get_price() == 100);

    std::cout << "Controller Tests Passed...\n";
}
