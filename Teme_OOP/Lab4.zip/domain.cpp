#include "domain.h"
using namespace Domain;


///implementing getters and setters for attributes of the fruit
Fruit::Fruit(const std::string& name, const std::string& origin, const Date& expiration_date, int quantity, int price) {
    this->name = name;
    this->origin = origin;
    this->quantity = quantity;
    this->price = price;
    this->expiration_date = expiration_date;
}

std::string Fruit::get_name() const{
    return this->name;
}

std::string Fruit::get_origin() const{
    return this->origin;
}

Fruit::Date Fruit::get_expiration_date() const{
    return expiration_date;
}

int Fruit::get_quantity() const{
    return this->quantity;
}

int Fruit::get_price() const{
    return this->price;
}

void Fruit::set_name(const std::string& other_name) {
    this->name = other_name;
}

void Fruit::set_origin(const std::string& other_origin) {
    this->origin = other_origin;
}

void Fruit::set_expiration_date(int year, int month, int day) {
    expiration_date.year = year;
    expiration_date.month = month;
    expiration_date.day = day;
}

void Fruit::set_quantity(int other_quantity){
    this->quantity = other_quantity;
}

void Fruit::set_price(int other_price){
    this->price = other_price;
}
