#include <string>
#include <iostream>
using namespace std;

//in the header file (.h) we declare the methods, in the cpp file we implement them

class Duration
{
private:
    double value;
    string unit;

public:
    Duration(double value, string unit);

    double get_value();

    string get_unit();

    Duration add(Duration object2);

    Duration subtract(Duration object2);

    Duration scale(double number);

    Duration divide(double number);

    std::string text();

    int compare(Duration object2);

    Duration convert_in(string other_unit);

    Duration operator+(Duration object2);

    Duration operator-(Duration object2);

    Duration operator*(double number);

    Duration operator/(double number);
};