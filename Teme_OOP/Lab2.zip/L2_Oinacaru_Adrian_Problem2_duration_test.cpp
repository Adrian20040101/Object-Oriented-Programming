#include <iostream>
#include <cassert>
#include "L2_Oinacaru_Adrian_Problem2_duration.cpp"

using namespace std;

void MethodTests() {
    // Testing constructor, get_value and get_unit methods
    Duration d(10, "minutes");
    assert(d.get_value() == 10);
    assert(d.get_unit() == "minutes");
    cout << "Constructor Test Passed..." << endl;

    // Testing add method
    Duration d2(4, "minutes");
    Duration d3 = d.add(d2);
    assert(d3.get_value() == 14);
    assert(d3.get_unit() == "minutes");
    //here we test the infix notation for the add method
    d3 = d + d2;
    assert(d3.get_value() == 14);
    cout << "Addition Test Passed..." << endl;

    // Testing subtract method
    Duration d4 = d.subtract(d2);
    assert(d4.get_value() == 6);
    assert(d4.get_unit() == "minutes");
    //here we test the infix notation for the subtract method
    d4 = d - d2;
    assert(d4.get_value() == 6);
    cout << "Subtraction Test Passed..." << endl;

    // Testing scale method
    Duration d5 = d.scale(2);
    assert(d5.get_value() == 20);
    assert(d5.get_unit() == "minutes");
    //here we test the infix notation for the scale method
    d5 = d * 2;
    assert(d5.get_value() == 20);
    cout << "Scaling Test Passed..." << endl;

    // Testing divide method
    Duration d6 = d.divide(4);
    assert(d6.get_value() == 2.5);
    assert(d6.get_unit() == "minutes");
    //here we test the infix notation for the divide method
    d6 = d / 4;
    assert(d6.get_value() == 2.5);
    cout << "Division Test Passed..." << endl;

    // Testing text method
    assert(d.text() == "Time: 10.00 minutes");
    cout << "Text Test Passed..." << endl;

    // Testing compare method
    Duration d7(75, "minutes");
    Duration d8(60, "minutes");
    assert(d7.compare(d8) == 1);
    cout << "Compare Test Passed..." << endl;

    //Testing convert method
    Duration d9(105, "minutes");
    d9.convert_in("hours");
    assert(d9.get_value() == 1.75);
    cout << "Convert Test Passed..." << endl;

    cout << "Method Tests Passed Successfully..." << endl << endl;
}

void UserTests() {

    // Taking user input for the object content and the number used to perform arithmetic operations
    double value1 = 0;
    std::string unit1;
    double value2 = 0;
    std::string unit2;
    double number = 0;
    cout << "Note that units given must be of the same type (either seconds, minutes or hours)" << endl;
    cout << "Write a value for the first object:";
    cin >> value1;
    cout << "Write a unit for the first object (seconds/minutes/hours):";
    cin >> unit1;
    cout << endl;
    cout << "Write a value for the second object:";
    cin >> value2;
    cout << "Write a value for the second object(seconds/minutes/hours):";
    cin >> unit2;
    cout << endl;
    cout << "Write a number which will be used to test the methods performing arithmetic operations:";
    cin >> number;
    cout << endl;

    // Testing constructor, get_value and get_unit methods
    Duration duration1(value1, unit1);
    Duration duration2(value2, unit2);
    assert(duration1.get_value() == value1);
    assert(duration2.get_value() == value2);
    assert(duration2.get_unit() == unit2);
    assert(duration2.get_unit() == unit2);
    if (duration1.get_unit() != duration2.get_unit()) {
        throw exception();
    }

    // Testing add method + the overloaded function
    // returns the expected value for demonstration purpose
    assert(duration1.add(duration2).get_value() == value1 + value2);
    Duration addExpectedResult(duration1.get_value() + duration2.get_value(), unit1);
    addExpectedResult = duration1 + duration2;
    assert(addExpectedResult.get_value() == duration1.get_value() + duration2.get_value());
    cout << "Add method result: " << addExpectedResult.get_value() << " " << addExpectedResult.get_unit() << endl;

    // Testing subtract method + the overloaded function
    // returns the expected value for demonstration purpose
    assert(duration1.subtract(duration2).get_value() == value1 - value2);
    Duration subtractExpectedResult(duration1.get_value() - duration2.get_value(), unit1);
    subtractExpectedResult = duration1 - duration2;
    assert(subtractExpectedResult.get_value() == duration1.get_value() - duration2.get_value());
    cout << "Subtract method result: " << subtractExpectedResult.get_value() << " " << subtractExpectedResult.get_unit()
         << endl;

    // Testing scale method + the overloaded function
    // returns the expected value for demonstration purpose
    assert(duration1.scale(number).get_value() == value1 * number);
    Duration multiplicationExpectedResult(duration1.get_value() * number, unit1);
    subtractExpectedResult = duration1 * number;
    assert(multiplicationExpectedResult.get_value() == duration1.get_value() * number);
    cout << "Scale method result: " << multiplicationExpectedResult.get_value() << " "
         << multiplicationExpectedResult.get_unit() << endl;

    // Testing divide method + the overloaded function
    // returns the expected value for demonstration purpose
    assert(duration1.divide(number).get_value() == value1 / number);
    Duration divisionExpectedResult(duration1.get_value() / number, unit1);
    subtractExpectedResult = duration1 / number;
    assert(divisionExpectedResult.get_value() == duration1.get_value() / number);
    cout << "Division method result: " << divisionExpectedResult.get_value() << " " << divisionExpectedResult.get_unit()
         << endl;

    //Testing compare method
    if (value1 > value2) {
        assert(duration1.compare(duration2) == 1);
        cout << "Compare method result: 1, since " << duration1.get_value() << " is greater than "
             << duration2.get_value() << endl << endl;
    } else if (value1 < value2) {
        assert(duration1.compare(duration2) == -1);
        cout << "Compare method result: -1, since " << duration1.get_value() << " is less than "
             << duration2.get_value() << endl << endl;
    } else {
        assert(duration1.compare(duration2) == 0);
        cout << "Compare method result: 0, since " << duration1.get_value() << " is equal to " << duration2.get_value()
             << endl << endl;
    }
}

int main() {
    MethodTests();
    UserTests();
    cout << "All Tests Passed Successfully..." << endl << endl;
}
