#include <iostream>
#include <iomanip>
#include "L2_Oinacaru_Adrian_Problem2_duration.h"

//here we implement the constructor
Duration::Duration(double value, string unit) {
    this->value = value;
    this->unit = unit;
}

//since the value and unit variables are declared as private, we need a getter to access them from outside of the class
double Duration::get_value() {
    return this->value;
}

string Duration::get_unit(){
    return this->unit;
}

/*this method takes another object as a parameter, verifies if the units are the same and performs an addition to their values
  if the conditions are met, if not it throws an exception. It returns another object*/
Duration Duration::add(Duration object2) {
    if (this->unit == object2.unit){
        return {this->value + object2.value, this->unit};
    } else{
        throw exception();
    }
}

/*this method takes another object as a parameter, verifies if the units are the same and performs a subtraction to their values
  if the conditions are met, if not it throws an exception. It returns another object*/
Duration Duration::subtract(Duration object2) {
    {
        if (this->unit == object2.unit) {
            return {this->value - object2.value, this->unit};
        } else {
            throw exception();
        }
    }
}

/*this method takes a floating point number as a parameter and performs a multiplication between the value of the object
  and the given parameter*/
Duration Duration::scale(double number) {
    return {this->value * number, this->unit};
}

/*this method takes a floating point number as a parameter and performs a division between the value of the object
  and the given parameter*/
Duration Duration::divide(double number) {
    return {this->value / number, this->unit};
}

//this method returns a string containing the value and the unit of the duration
std::string Duration::text() {
    std::stringstream stream;
    stream << std::fixed<<std::setprecision(2)<< this->value;
    return "Time: " + stream.str() + " " + this->unit;
}

/*this method compares the values of two objects that have the same unit and returns either 1, 0, -1 or an exception if
  the conditions are not met*/
int Duration::compare(Duration object2) {
    {
        if (this->unit == object2.unit && this->value < object2.value) {
            return -1;
        }
        else if(this->unit == object2.unit && this->value == object2.value){
            return 0;
        }
        else if(this->unit == object2.unit && this->value > object2.value){
            return 1;
        }
        else {
            throw exception();
        }
    }
}

/*this method takes a string as a parameter, indicating to which unit we are going to perform the conversion to. It returns an
  object containing the updated value and unit, or an exception when none of the conditions are met*/
Duration Duration::convert_in(string other_unit) {
    if (this->unit == "seconds" && other_unit == "minutes"){
        this->value /= 60;
        return {this->value, this->unit};
    }
    else if (this->unit == "minutes" && other_unit == "seconds"){
        this->value *= 60;
        return {this->value, this->unit};
    }

    else if (this->unit == "minutes" && other_unit == "hours"){
        this->value /= 60;
        return {this->value, this->unit};

    }
    else if (this->unit == "hours" && other_unit == "minutes"){
        this->value *= 60;
        return {this->value * 60, this->unit};
    }

    else{
        throw exception();
    }
}

//the following 4 methods are used for the infix notation of the arithmetic operations and are called overloaded functions

/*operator+ is an overloaded function. When '+' is used with two objects of type Duration, this method will be called to
  perform the operation. It returns another object whose value is equal to the sum of the values of the two objects that
  have been used here, or an exception if the units of the two objects whose values we want to add don't match*/
Duration Duration::operator+(Duration object2) {
    if (this->unit == object2.unit){
        return {this->value + object2.value, this->unit};
    } else{
        throw exception();
    }
}

/*operator- is an overloaded function. When '-' is used with two objects of type Duration, this method will be called to
  perform the operation. It returns another object whose value is equal to the difference of the values of the two objects
  that have been used here, or an exception if the units of the two objects whose values we want to subtract don't match*/
Duration Duration::operator-(Duration object2) {
    if (this->unit == object2.unit){
        return {this->value - object2.value, this->unit};
    } else{
        throw exception();
    }
}

/*operator* is an overloaded function. When '*' is used with an object of type Duration and a floating point number,
  this method will be called to perform the operation. It returns another object whose value is equal to the multiplication
  between the value of the object and the given number*/
Duration Duration::operator*(double number) {

    return {this->value * number, this->unit};
}

/*operator/ is an overloaded function. When '/' is used with an object of type Duration and a floating point number,
  this method will be called to perform the operation. It returns another object whose value is equal to the division
  between the value of the object and the given number*/
Duration Duration::operator/(double number) {

    return {this->value / number, this->unit};
}