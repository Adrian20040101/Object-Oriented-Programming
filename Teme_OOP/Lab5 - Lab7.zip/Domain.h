#pragma once


namespace Domain {
    class Scooter;
    class User;
}
